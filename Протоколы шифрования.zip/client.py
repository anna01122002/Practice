import socket


class DH_Endpoint(object):
    def __init__(self, public_key1, public_key2, private_key):
        self.public_key1 = public_key1
        self.public_key2 = public_key2
        self.private_key = private_key
        self.full_key = None

    def generate_partial_key(self):
        partial_key = self.public_key1 ** self.private_key
        partial_key = partial_key % self.public_key2
        return partial_key

    def generate_full_key(self, partial_key_r):
        full_key = partial_key_r ** self.private_key
        full_key = full_key % self.public_key2
        self.full_key = full_key
        return full_key

    def encrypt_message(self, message):
        encrypted_message = ""
        key = self.full_key
        for c in message:
            encrypted_message += chr(ord(c) + key)
        return encrypted_message

    def decrypt_message(self, encrypted_message):
        decrypted_message = ""
        key = self.full_key
        for c in encrypted_message:
            decrypted_message += chr(ord(c) - key)
        return decrypted_message


HOST = 'localhost'  # The server's hostname or IP address
PORT = 9046 # The port used by the server

public_key = 151
private_key = 157

f = open('client_key.txt', 'r+')
file_info = ['Открытый ключ:\n', str(public_key), '\nЗакрытый ключ:\n', str(private_key)]
lines = f.readlines()

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    print('Connected by', HOST)
    count = 0

    while True:
        if count == 0:
            message = lines[1]
            bytemessage = bytes(message, 'UTF-8')
            s.send(bytemessage)
            data = s.recv(1024)
        if count == 1:
            server_key = int(data)
            print('Получен публичный ключ:', server_key)
            Secret = DH_Endpoint(server_key, public_key, private_key)
            Partkey = Secret.generate_partial_key()
            print('Получен частичный ключ:', Partkey)
            message = str(Partkey)
            bytemessage = bytes(message, 'UTF-8')
            s.send(bytemessage)
            data = s.recv(1024)
        if count == 2:
            server_part_key = int(data)
            Key = Secret.generate_full_key(server_part_key)
            print('Получен полный ключ:', Key)
            f.close()
        if count >= 3:
            message = input()
            S_message = Secret.encrypt_message(message)
            bytemessage = bytes(S_message, 'UTF-8')
            s.send(bytemessage)
            data = s.recv(1024)
            data = data.decode()
            data = Secret.decrypt_message(data)
            print(data)

        count += 1
        if not data:
            break
