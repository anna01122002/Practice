import socket


class DH_Endpoint(object):
    def __init__(self, public_key1, public_key2, private_key):
        self.public_key1 = public_key1
        self.public_key2 = public_key2
        self.private_key = private_key
        self.full_key = None

    def generate_partial_key(self):
        partial_key = self.public_key1 ** self.private_key
        partial_key = partial_key % self.public_key2
        return partial_key

    def generate_full_key(self, partial_key_r):
        full_key = partial_key_r ** self.private_key
        full_key = full_key % self.public_key2
        self.full_key = full_key
        return full_key

    def encrypt_message(self, message):
        encrypted_message = ""
        key = self.full_key
        for c in message:
            encrypted_message += chr(ord(c) + key)
        return encrypted_message

    def decrypt_message(self, encrypted_message):
        decrypted_message = ""
        key = self.full_key
        for c in encrypted_message:
            decrypted_message += chr(ord(c) - key)
        return decrypted_message


HOST = 'localhost'
PORT = 9046 # (non-privileged ports are > 1023)

public_key = 197
private_key = 199

f = open('server_key.txt', 'r+')
file_info = ['Открытый ключ:\n', str(public_key), '\nЗакрытый ключ:\n', str(private_key)]
lines = f.readlines()


accept = ['151', '152', '153']

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    with conn:
        print('Connected by', addr)
        count = 0

        while True:
            # print('--ОТКЛАДКА-- ', count)
            data = conn.recv(1024)
            count += 1
            if count == 1:
                client_key = int(data)
                if str(client_key) in accept:
                    pass
                else:
                    print('Подключение не авторизованно! Соединение завершено!')
                    break
                print('Получен публичный ключ:', client_key)
                Secret = DH_Endpoint(public_key, client_key, private_key)
                Partkey = Secret.generate_partial_key()
                print('Получен частичный ключ:', Partkey)
                message = lines[1]
                bytemessage = bytes(message, 'UTF-8')
                data = conn.send(bytemessage)
            if count == 2:
                client_part_key = int(data)
                Key = Secret.generate_full_key(client_part_key)
                print('Получен полный ключ:', Key)
                message = str(Partkey)
                bytemessage = bytes(message, 'UTF-8')
                data = conn.send(bytemessage)
                f.close()
            if count >= 3:
                data = data.decode()
                data = Secret.decrypt_message(data)
                print(data)
                message = input()
                m_encrypted = Secret.encrypt_message(message)
                bytemessage = bytes(m_encrypted, 'UTF-8')
                data = conn.send(bytemessage)

            if not data:
                break
